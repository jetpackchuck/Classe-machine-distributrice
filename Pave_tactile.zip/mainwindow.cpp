#include "mainwindow.h"
#include "./ui_mainwindow.h"

using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->Bouton_1, &QPushButton::pressed, this, &MainWindow::Bouton_1);
    connect(ui->Bouton_2, &QPushButton::pressed, this, &MainWindow::Bouton_2);
    connect(ui->Bouton_3, &QPushButton::pressed, this, &MainWindow::Bouton_3);
    connect(ui->Bouton_4, &QPushButton::pressed, this, &MainWindow::Bouton_4);
    connect(ui->Bouton_5, &QPushButton::pressed, this, &MainWindow::Bouton_5);
    connect(ui->Bouton_6, &QPushButton::pressed, this, &MainWindow::Bouton_6);
    connect(ui->Bouton_Validation, &QPushButton::pressed, this, &MainWindow::Bouton_Validation);
    connect(ui->Bouton_Annulation, &QPushButton::pressed, this, &MainWindow::Bouton_Annulation);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::Bouton_1()
{
    _choix +="1";
    if (_choix.size() <= 2)
    {

        ui->label->setText(QString::fromStdString(_choix));
    }

}

void MainWindow::Bouton_2()
{
    _choix += "2";
    if (_choix.size() <= 2)
    {

        ui->label->setText(QString::fromStdString(_choix));
    }
}


void MainWindow::Bouton_3()
{
    _choix += "3";
    if (_choix.size() <= 2)
    {

        ui->label->setText(QString::fromStdString(_choix));
    }
}


void MainWindow::Bouton_4()
{
    _choix += "4";
    if (_choix.size() <= 2)
    {

        ui->label->setText(QString::fromStdString(_choix));
    }
}


void MainWindow::Bouton_5()
{
    _choix += "5";
    if (_choix.size() <= 2)
    {

        ui->label->setText(QString::fromStdString(_choix));
    }
}


void MainWindow::Bouton_6()
{
    _choix += "6";
    if (_choix.size() <= 2)
    {

        ui->label->setText(QString::fromStdString(_choix));
    }
}


void MainWindow::Bouton_Validation()
{
    if(_choix == ""){

    }
    else{
        if(_choix.size()>2){
            _choix.resize(2);
        }
        if(_choix.size()==2 && _choix[1]!='6')
        {
            ui->label->setText("Choix validé");
        }
        else{
            ui->label->setText("Ce n'est pas un choix valide");
            _choix = "";
        }
    }
}


void MainWindow::Bouton_Annulation()
{
    _choix = "";
    ui->label->setText(QString::fromStdString(_choix));
 }

