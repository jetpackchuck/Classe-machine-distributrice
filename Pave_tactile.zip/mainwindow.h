#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    std::string _choix;

private slots:

    void Bouton_1();

    void Bouton_2();

    void Bouton_3();

    void Bouton_4();

    void Bouton_5();

    void Bouton_6();

    void Bouton_Validation();

    void Bouton_Annulation();


private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
